#ifndef __FRONTDESKTESTCALLER_H__
#define __FRONTDESKTESTCALLER_H__

#include <string>
#include <cppunit/TestCaller.h>
#include "FrontDeskTestCase.h"

using namespace std;
using namespace CppUnit;

namespace FDCppUnit {

template <typename Fixture, typename ExpectedException = NoExceptionExpected>
class FrontDeskTestCaller : public FrontDeskTestCase {
	typedef void (Fixture::*TestMethod)();
public:

	FrontDeskTestCaller(string name, TestMethod test, double fail, double error) : 
	FrontDeskTestCase(name, fail, error), m_test(test), m_ownFixture(true), m_fixture(new Fixture()) { }
	FrontDeskTestCaller(string name, TestMethod test, Fixture& fixture, double fail, double error) : 
	FrontDeskTestCase(name, fail, error), m_test(test), m_ownFixture(false), m_fixture(&fixture) { }
	FrontDeskTestCaller(string name, TestMethod test, Fixture* fixture, double fail, double error) : 
	FrontDeskTestCase(name, fail, error), m_test(test), m_ownFixture(true), m_fixture(fixture) { }

	virtual ~FrontDeskTestCaller() { 
		if (m_ownFixture)
			delete m_fixture;
	}

protected:

	void runTest() { 
		try {
			(m_fixture->*m_test)();
		}
		catch (ExpectedException&) {
			return;
		}
		ExpectedExceptionTraits<ExpectedException>::expectedException();
	}  

	void setUp() { 
		m_fixture->setUp (); 
	}

	void tearDown() { 
		m_fixture->tearDown (); 
	}

	string toString() const { 
		return "TestCaller " + getName(); 
	}

private:

	bool m_ownFixture;
	Fixture *m_fixture;
	TestMethod m_test;
};

}

#endif
