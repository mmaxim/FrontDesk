#ifndef __FRONTDESKTESTCASE_H__
#define __FRONTDESKTESTCASE_H__

#include <string>
#include <cppunit/TestCase.h>

using namespace std;
using namespace CppUnit;

namespace FDCppUnit {
class FrontDeskTestCase : public TestCase {
public:

	FrontDeskTestCase(double fail, double error) : 
			TestCase(), m_fail(fail), m_error(error) { }
	FrontDeskTestCase(string name, double fail, double error) : 
			TestCase(name), m_fail(fail), m_error(error) { }
	virtual ~FrontDeskTestCase() { }

	virtual double getFailPoints() { return m_fail; }
	virtual double getErrorPoints() { return m_error; }

protected:

	double m_fail, m_error;

};
}

#endif
